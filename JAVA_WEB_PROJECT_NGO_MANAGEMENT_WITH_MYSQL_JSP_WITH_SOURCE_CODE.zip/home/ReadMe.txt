Configration..........

IDE: netbeans 8.0
HTML
Servlet
CSS
MySQL as a backend databse......